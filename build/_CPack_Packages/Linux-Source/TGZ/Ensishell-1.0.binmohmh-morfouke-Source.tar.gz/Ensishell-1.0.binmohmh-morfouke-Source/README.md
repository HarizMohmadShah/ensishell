ensimag-shell
=============

Squelette pour le TP shell

Tous les fichiers sont sous licence GPLv3+

Introduction
----------

Ces fichiers servent de base à un TP sur le shell de commande à la Unix.

Spécificités de ce squelette:
- plusieurs variantes (choix par sha512 sur les logins des étudiants)
- jeux de tests fournis aux étudiants

Compilation et lancement des tests
----------

cd ensimag-shell
cd build
cmake ..
make
make test



